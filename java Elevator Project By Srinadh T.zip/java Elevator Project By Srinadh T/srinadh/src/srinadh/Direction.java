package srinadh;

public enum Direction {
	 UP,
	 DOWN,
	 IDLE
	}